export const environment = {
    production: false,
    firebase: {
      apiKey: 'AIzaSyDF94GqTblVuMdEItpmD5LyxPGwHpi2Kic',
    //   authDomain: 'YOUR_AUTH_DOMAIN',
      projectId: 'chat-app-1d80a',
    //   storageBucket: 'YOUR_STORAGE_BUCKET',
    //   messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    //   appId: 'YOUR_APP_ID'
    }
  };
  
  
  
  
  
  
  